﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(PRG522SA.Startup))]
namespace PRG522SA
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
